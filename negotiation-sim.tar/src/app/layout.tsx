import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Negotiation Simulator',
  description: 'ZS pricing framework — principal negotiation simulations',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
