import Link from 'next/link';
import { requireUser } from '@/lib/guards';
import { prisma } from '@/lib/prisma';

export default async function PrincipalHome() {
  const user = await requireUser();

  const assignments = await prisma.assignment.findMany({
    where: { userId: user.id },
    include: { persona: true, case: true, sessions: { orderBy: { createdAt: 'desc' }, take: 1 } },
    orderBy: { createdAt: 'asc' },
  });

  const allComplete = assignments.length > 0 && assignments.every((a) => a.status === 'ANALYZED' || a.status === 'COMPLETE');

  return (
    <div>
      <h1 className="text-2xl font-semibold text-navy">Your assignments</h1>
      <p className="mt-2 text-sm text-ink/70">
        Three negotiation simulations. Each one is a different client persona and engagement scenario.
        Block 20 minutes per session and find a quiet space — once you start, there&apos;s no pause/resume.
      </p>

      {assignments.length === 0 ? (
        <div className="mt-8 rounded-md border border-ink/10 bg-white p-6 text-sm text-ink/70">
          No assignments yet. Once Jay has set things up, they&apos;ll appear here.
        </div>
      ) : (
        <div className="mt-8 grid gap-4">
          {assignments.map((a, i) => (
            <div key={a.id} className="rounded-md border border-ink/10 bg-white p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wide text-ink/50">
                    Interview {i + 1} of {assignments.length}
                  </div>
                  <div className="mt-1 text-lg font-semibold text-navy">{a.case.headline}</div>
                  <div className="text-sm text-ink/70">
                    Persona: {a.persona.name} — {a.persona.role}, {a.persona.company}
                  </div>
                </div>
                <StatusBadge status={a.status} />
              </div>
              <div className="mt-4 flex gap-3">
                <Link
                  href={`/principal/assignment/${a.id}`}
                  className="rounded-md border border-ink/20 px-3 py-2 text-sm hover:bg-ink/5"
                >
                  View brief
                </Link>
                {a.status !== 'COMPLETE' && a.status !== 'ANALYZED' && (
                  <Link
                    href={`/interview/${a.id}`}
                    className="rounded-md bg-navy px-3 py-2 text-sm font-medium text-white hover:bg-navy/90"
                  >
                    Start interview
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {allComplete && (
        <div className="mt-8 rounded-md border border-teal/30 bg-teal/5 p-6">
          <div className="text-sm font-semibold text-navy">Your feedback report is ready</div>
          <Link href="/principal/report" className="mt-2 inline-block text-sm text-teal underline">
            View report
          </Link>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    ASSIGNED: 'bg-ink/10 text-ink/70',
    IN_PROGRESS: 'bg-amber-100 text-amber-800',
    COMPLETE: 'bg-teal/10 text-teal',
    ANALYZED: 'bg-teal/10 text-teal',
  };
  const label: Record<string, string> = {
    ASSIGNED: 'Not started',
    IN_PROGRESS: 'In progress',
    COMPLETE: 'Complete',
    ANALYZED: 'Analyzed',
  };
  return (
    <span className={`rounded-full px-2 py-1 text-xs ${map[status] ?? map.ASSIGNED}`}>
      {label[status] ?? status}
    </span>
  );
}
