import { requireUser } from '@/lib/guards';
import { signOut } from '@/lib/auth';

export default async function PrincipalLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();

  async function logout() {
    'use server';
    await signOut({ redirectTo: '/login' });
  }

  return (
    <div>
      <header className="border-b border-ink/10 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <div>
            <div className="text-sm font-semibold text-navy">Negotiation Simulator</div>
            <div className="text-xs text-ink/60">{user.email}</div>
          </div>
          <form action={logout}>
            <button className="text-xs text-ink/60 hover:text-ink">Sign out</button>
          </form>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-6 py-10">{children}</main>
    </div>
  );
}
