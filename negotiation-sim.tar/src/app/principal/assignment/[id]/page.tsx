import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireUser } from '@/lib/guards';
import { prisma } from '@/lib/prisma';

export default async function AssignmentBrief({ params }: { params: { id: string } }) {
  const user = await requireUser();
  const a = await prisma.assignment.findUnique({
    where: { id: params.id },
    include: { persona: true, case: true },
  });
  if (!a || a.userId !== user.id) notFound();

  const pricingOptions = safeArray(a.case.pricingOptions);

  return (
    <div>
      <Link href="/principal" className="text-xs text-ink/60 hover:text-ink">← Back to assignments</Link>
      <h1 className="mt-2 text-2xl font-semibold text-navy">{a.case.headline}</h1>

      <section className="mt-6 grid gap-6 md:grid-cols-2">
        <Card title="Engagement context">
          <Field label="Client" value={a.case.clientName} />
          <Field label="Scope" value={a.case.scope} />
          <Field label="Value" value={a.case.value} />
          <Field label="Timeline" value={a.case.timeline} />
          <Field label="Competing firms" value={a.case.competingFirms} />
          <Field label="Complications" value={a.case.complications} />
        </Card>

        <Card title="Your objective">
          <p className="text-sm">{a.case.objective}</p>
          <div className="mt-4 text-xs uppercase tracking-wide text-ink/50">Constraints</div>
          <p className="mt-1 text-sm">{a.case.constraints}</p>
          <div className="mt-4 text-xs uppercase tracking-wide text-ink/50">Pricing models in play</div>
          <p className="mt-1 text-sm">{pricingOptions.join(' · ') || 'Open'}</p>
        </Card>

        <Card title="Who you&apos;re negotiating with">
          <Field label="Name" value={a.persona.name} />
          <Field label="Role" value={`${a.persona.role}, ${a.persona.company}`} />
          <Field label="Decision authority" value={a.persona.decisionAuthority} />
        </Card>

        <Card title="Logistics">
          <p className="text-sm">
            Plan for ~17 minutes. The persona will wind the conversation down naturally.
            You can reference this brief in a side panel during the call.
          </p>
          <p className="mt-3 text-sm text-ink/70">
            By starting, you confirm you understand the call will be recorded, transcribed, and analyzed.
            You will receive a personal feedback report. An aggregate cross-principal synthesis is shared
            with leadership for the pricing framework project.
          </p>
        </Card>
      </section>

      <div className="mt-8">
        <Link
          href={`/interview/${a.id}`}
          className="inline-block rounded-md bg-navy px-4 py-2 text-sm font-medium text-white hover:bg-navy/90"
        >
          Start interview
        </Link>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-ink/10 bg-white p-5">
      <div className="text-xs uppercase tracking-wide text-ink/50">{title}</div>
      <div className="mt-3 space-y-2">{children}</div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-sm">
      <span className="text-ink/50">{label}: </span>
      <span>{value}</span>
    </div>
  );
}

function safeArray(s: string): string[] {
  try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return s ? [s] : []; }
}
