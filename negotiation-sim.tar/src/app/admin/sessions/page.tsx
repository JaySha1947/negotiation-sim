import { prisma } from '@/lib/prisma';

export default async function SessionsPage() {
  const sessions = await prisma.session.findMany({
    include: { user: true, assignment: { include: { persona: true, case: true } } },
    orderBy: { createdAt: 'desc' },
  });
  return (
    <div>
      <h1 className="text-2xl font-semibold text-navy">Sessions</h1>
      <p className="mt-1 text-sm text-ink/60">Voice + analysis come online in week 2/3. This is the live view.</p>
      <table className="mt-6 w-full border-collapse rounded-md border border-ink/10 bg-white text-sm">
        <thead>
          <tr className="border-b border-ink/10 text-left text-xs uppercase tracking-wide text-ink/50">
            <th className="px-4 py-2">Principal</th><th className="px-4 py-2">Persona</th>
            <th className="px-4 py-2">Case</th><th className="px-4 py-2">Status</th>
            <th className="px-4 py-2">Duration</th><th className="px-4 py-2">Created</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((s) => (
            <tr key={s.id} className="border-b border-ink/5">
              <td className="px-4 py-2">{s.user.email}</td>
              <td className="px-4 py-2">{s.assignment.persona.name}</td>
              <td className="px-4 py-2">{s.assignment.case.name}</td>
              <td className="px-4 py-2 text-xs">{s.status}</td>
              <td className="px-4 py-2">{s.durationSec ? `${Math.round(s.durationSec / 60)}m` : '—'}</td>
              <td className="px-4 py-2 text-xs text-ink/50">{s.createdAt.toISOString().slice(0, 16).replace('T', ' ')}</td>
            </tr>
          ))}
          {sessions.length === 0 && (
            <tr><td colSpan={6} className="px-4 py-6 text-center text-ink/60">No sessions yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
