import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export default async function CasesPage() {
  const cases = await prisma.case.findMany({ where: { archived: false }, orderBy: { createdAt: 'asc' } });
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-navy">Cases</h1>
        <Link href="/admin/cases/new" className="rounded-md bg-navy px-4 py-2 text-sm font-medium text-white">+ New case</Link>
      </div>
      <div className="mt-6 grid gap-3">
        {cases.map((c) => (
          <Link key={c.id} href={`/admin/cases/${c.id}`}
                className="rounded-md border border-ink/10 bg-white p-5 hover:border-teal/40">
            <div className="text-base font-semibold text-navy">{c.name}</div>
            <div className="text-sm text-ink/70">{c.headline}</div>
            <div className="mt-2 text-xs text-ink/50">{c.clientName} · {c.value} · {c.timeline}</div>
          </Link>
        ))}
        {cases.length === 0 && (
          <div className="rounded-md border border-ink/10 bg-white p-6 text-sm text-ink/60">No cases yet.</div>
        )}
      </div>
    </div>
  );
}
