import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import CaseForm from '@/components/CaseForm';

export default function NewCase() {
  async function create(data: any) {
    'use server';
    const opts = (data.pricingOptions as string).split(',').map((s: string) => s.trim()).filter(Boolean);
    const created = await prisma.case.create({ data: { ...data, pricingOptions: JSON.stringify(opts) } });
    redirect(`/admin/cases/${created.id}`);
  }
  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold text-navy">New case</h1>
      <div className="mt-6"><CaseForm action={create} /></div>
    </div>
  );
}
