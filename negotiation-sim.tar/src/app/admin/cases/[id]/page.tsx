import { notFound, redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import CaseForm from '@/components/CaseForm';

export default async function EditCase({ params }: { params: { id: string } }) {
  const c = await prisma.case.findUnique({ where: { id: params.id } });
  if (!c) notFound();
  let opts = '';
  try { const arr = JSON.parse(c.pricingOptions); if (Array.isArray(arr)) opts = arr.join(', '); } catch {}

  async function save(data: any) {
    'use server';
    const arr = (data.pricingOptions as string).split(',').map((s: string) => s.trim()).filter(Boolean);
    await prisma.case.update({ where: { id: params.id }, data: { ...data, pricingOptions: JSON.stringify(arr) } });
    redirect('/admin/cases');
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold text-navy">Edit case</h1>
      <div className="mt-6"><CaseForm initial={{ ...c, pricingOptions: opts }} action={save} /></div>
    </div>
  );
}
