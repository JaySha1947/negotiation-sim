import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export default async function PrincipalsPage() {
  const users = await prisma.user.findMany({
    where: { role: 'PRINCIPAL' },
    orderBy: { createdAt: 'asc' },
    include: { _count: { select: { assignments: true, sessions: true } } },
  });

  async function createPrincipal(formData: FormData) {
    'use server';
    const email = String(formData.get('email') ?? '').trim().toLowerCase();
    const name = String(formData.get('name') ?? '').trim() || null;
    if (!email) return;
    await prisma.user.upsert({
      where: { email },
      update: { name: name ?? undefined },
      create: { email, name, role: 'PRINCIPAL' },
    });
    revalidatePath('/admin/principals');
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-navy">Principals</h1>

      <form action={createPrincipal} className="mt-6 flex gap-3 rounded-md border border-ink/10 bg-white p-4">
        <input name="email" type="email" required placeholder="email@zs.com"
               className="flex-1 rounded-md border border-ink/20 px-3 py-2 text-sm" />
        <input name="name" type="text" placeholder="Full name (optional)"
               className="flex-1 rounded-md border border-ink/20 px-3 py-2 text-sm" />
        <button className="rounded-md bg-navy px-4 py-2 text-sm font-medium text-white">Add</button>
      </form>

      <table className="mt-6 w-full border-collapse rounded-md border border-ink/10 bg-white text-sm">
        <thead>
          <tr className="border-b border-ink/10 text-left text-xs uppercase tracking-wide text-ink/50">
            <th className="px-4 py-2">Email</th>
            <th className="px-4 py-2">Name</th>
            <th className="px-4 py-2">Assignments</th>
            <th className="px-4 py-2">Sessions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id} className="border-b border-ink/5">
              <td className="px-4 py-2">{u.email}</td>
              <td className="px-4 py-2">{u.name ?? '—'}</td>
              <td className="px-4 py-2">{u._count.assignments}</td>
              <td className="px-4 py-2">{u._count.sessions}</td>
            </tr>
          ))}
          {users.length === 0 && (
            <tr><td colSpan={4} className="px-4 py-6 text-center text-ink/60">No principals yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
