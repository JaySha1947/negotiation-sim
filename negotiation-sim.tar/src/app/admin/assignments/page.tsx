import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export default async function AssignmentsPage() {
  const [users, personas, cases, assignments] = await Promise.all([
    prisma.user.findMany({ where: { role: 'PRINCIPAL' }, orderBy: { email: 'asc' } }),
    prisma.persona.findMany({ where: { archived: false }, orderBy: { name: 'asc' } }),
    prisma.case.findMany({ where: { archived: false }, orderBy: { name: 'asc' } }),
    prisma.assignment.findMany({ include: { user: true, persona: true, case: true }, orderBy: { createdAt: 'desc' } }),
  ]);

  async function createAssignment(formData: FormData) {
    'use server';
    const userId = String(formData.get('userId'));
    const personaId = String(formData.get('personaId'));
    const caseId = String(formData.get('caseId'));
    if (!userId || !personaId || !caseId) return;
    try {
      await prisma.assignment.create({ data: { userId, personaId, caseId } });
    } catch {
      // unique constraint hit — assignment already exists
    }
    revalidatePath('/admin/assignments');
  }

  async function deleteAssignment(formData: FormData) {
    'use server';
    const id = String(formData.get('id'));
    await prisma.assignment.delete({ where: { id } });
    revalidatePath('/admin/assignments');
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold text-navy">Assignments</h1>

      <form action={createAssignment} className="mt-6 grid gap-3 rounded-md border border-ink/10 bg-white p-4 md:grid-cols-4">
        <select name="userId" required className="rounded-md border border-ink/20 px-3 py-2 text-sm">
          <option value="">Principal…</option>
          {users.map((u) => <option key={u.id} value={u.id}>{u.email}</option>)}
        </select>
        <select name="personaId" required className="rounded-md border border-ink/20 px-3 py-2 text-sm">
          <option value="">Persona…</option>
          {personas.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <select name="caseId" required className="rounded-md border border-ink/20 px-3 py-2 text-sm">
          <option value="">Case…</option>
          {cases.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <button className="rounded-md bg-navy px-4 py-2 text-sm font-medium text-white">Add assignment</button>
      </form>

      <table className="mt-6 w-full border-collapse rounded-md border border-ink/10 bg-white text-sm">
        <thead>
          <tr className="border-b border-ink/10 text-left text-xs uppercase tracking-wide text-ink/50">
            <th className="px-4 py-2">Principal</th>
            <th className="px-4 py-2">Persona</th>
            <th className="px-4 py-2">Case</th>
            <th className="px-4 py-2">Status</th>
            <th className="px-4 py-2"></th>
          </tr>
        </thead>
        <tbody>
          {assignments.map((a) => (
            <tr key={a.id} className="border-b border-ink/5">
              <td className="px-4 py-2">{a.user.email}</td>
              <td className="px-4 py-2">{a.persona.name}</td>
              <td className="px-4 py-2">{a.case.name}</td>
              <td className="px-4 py-2 text-xs">{a.status}</td>
              <td className="px-4 py-2 text-right">
                <form action={deleteAssignment}>
                  <input type="hidden" name="id" value={a.id} />
                  <button className="text-xs text-ink/50 hover:text-red-600">Remove</button>
                </form>
              </td>
            </tr>
          ))}
          {assignments.length === 0 && (
            <tr><td colSpan={5} className="px-4 py-6 text-center text-ink/60">No assignments yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
