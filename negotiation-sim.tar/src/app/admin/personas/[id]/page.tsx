import { notFound, redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import PersonaForm from '@/components/PersonaForm';

export default async function EditPersona({ params }: { params: { id: string } }) {
  const p = await prisma.persona.findUnique({ where: { id: params.id } });
  if (!p) notFound();

  // De-serialize objections JSON back to one-per-line for the form
  let objLines = '';
  try { const arr = JSON.parse(p.knownObjections); if (Array.isArray(arr)) objLines = arr.join('\n'); } catch {}

  async function save(data: any) {
    'use server';
    const objs = (data.knownObjections as string)
      .split('\n').map((s: string) => s.trim()).filter(Boolean);
    await prisma.persona.update({
      where: { id: params.id },
      data: { ...data, knownObjections: JSON.stringify(objs) },
    });
    redirect('/admin/personas');
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold text-navy">Edit persona</h1>
      <div className="mt-6">
        <PersonaForm initial={{ ...p, knownObjections: objLines }} action={save} />
      </div>
    </div>
  );
}
