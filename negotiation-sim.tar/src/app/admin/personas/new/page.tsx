import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import PersonaForm from '@/components/PersonaForm';

export default function NewPersona() {
  async function create(data: any) {
    'use server';
    // Convert objections (one per line) to JSON array string
    const objs = (data.knownObjections as string)
      .split('\n').map((s: string) => s.trim()).filter(Boolean);

    const created = await prisma.persona.create({
      data: { ...data, knownObjections: JSON.stringify(objs) },
    });
    redirect(`/admin/personas/${created.id}`);
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold text-navy">New persona</h1>
      <p className="mt-1 text-sm text-ink/60">
        These structured fields are assembled into the AI&apos;s system prompt at runtime.
      </p>
      <div className="mt-6"><PersonaForm action={create} /></div>
    </div>
  );
}
