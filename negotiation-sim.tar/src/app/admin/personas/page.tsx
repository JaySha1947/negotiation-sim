import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export default async function PersonasPage() {
  const personas = await prisma.persona.findMany({
    where: { archived: false },
    orderBy: { createdAt: 'asc' },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-navy">Personas</h1>
        <Link href="/admin/personas/new" className="rounded-md bg-navy px-4 py-2 text-sm font-medium text-white">
          + New persona
        </Link>
      </div>

      <div className="mt-6 grid gap-3">
        {personas.map((p) => (
          <Link key={p.id} href={`/admin/personas/${p.id}`}
                className="rounded-md border border-ink/10 bg-white p-5 hover:border-teal/40">
            <div className="text-base font-semibold text-navy">{p.name}</div>
            <div className="text-sm text-ink/70">{p.role} — {p.company}</div>
            <div className="mt-2 text-xs text-ink/50">
              Difficulty {p.difficulty}/5 · Sensitivity {p.pricingSensitivity}/5 · Voice: {p.voice}
            </div>
          </Link>
        ))}
        {personas.length === 0 && (
          <div className="rounded-md border border-ink/10 bg-white p-6 text-sm text-ink/60">
            No personas yet. Add one to get started.
          </div>
        )}
      </div>
    </div>
  );
}
