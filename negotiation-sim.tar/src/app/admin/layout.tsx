import Link from 'next/link';
import { requireAdmin } from '@/lib/guards';
import { signOut } from '@/lib/auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();

  async function logout() {
    'use server';
    await signOut({ redirectTo: '/login' });
  }

  return (
    <div>
      <header className="border-b border-ink/10 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-6">
            <div className="text-sm font-semibold text-navy">Admin</div>
            <nav className="flex gap-4 text-sm text-ink/70">
              <Link href="/admin">Dashboard</Link>
              <Link href="/admin/principals">Principals</Link>
              <Link href="/admin/personas">Personas</Link>
              <Link href="/admin/cases">Cases</Link>
              <Link href="/admin/assignments">Assignments</Link>
              <Link href="/admin/sessions">Sessions</Link>
            </nav>
          </div>
          <form action={logout}>
            <button className="text-xs text-ink/60 hover:text-ink">Sign out</button>
          </form>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-10">{children}</main>
    </div>
  );
}
