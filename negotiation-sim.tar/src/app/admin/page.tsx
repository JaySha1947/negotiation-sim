import { prisma } from '@/lib/prisma';

export default async function AdminDashboard() {
  const [users, personas, cases, assignments, sessions] = await Promise.all([
    prisma.user.count({ where: { role: 'PRINCIPAL' } }),
    prisma.persona.count({ where: { archived: false } }),
    prisma.case.count({ where: { archived: false } }),
    prisma.assignment.count(),
    prisma.session.count(),
  ]);

  const cards = [
    { label: 'Principals', value: users },
    { label: 'Personas', value: personas },
    { label: 'Cases', value: cases },
    { label: 'Assignments', value: assignments },
    { label: 'Sessions', value: sessions },
  ];

  return (
    <div>
      <h1 className="text-2xl font-semibold text-navy">Dashboard</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 md:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="rounded-md border border-ink/10 bg-white p-5">
            <div className="text-xs uppercase tracking-wide text-ink/50">{c.label}</div>
            <div className="mt-1 text-2xl font-semibold text-navy">{c.value}</div>
          </div>
        ))}
      </div>
      <p className="mt-8 text-sm text-ink/70">
        Week 1 build. Voice and analysis pipelines come online in weeks 2 and 3.
      </p>
    </div>
  );
}
