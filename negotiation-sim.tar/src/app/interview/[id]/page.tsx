import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireUser } from '@/lib/guards';
import { prisma } from '@/lib/prisma';

export default async function InterviewPage({ params }: { params: { id: string } }) {
  const user = await requireUser();
  const a = await prisma.assignment.findUnique({
    where: { id: params.id }, include: { persona: true, case: true },
  });
  if (!a || a.userId !== user.id) notFound();

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <Link href={`/principal/assignment/${a.id}`} className="text-xs text-ink/60 hover:text-ink">← Back to brief</Link>
      <h1 className="mt-2 text-2xl font-semibold text-navy">Interview — {a.case.headline}</h1>
      <div className="mt-2 text-sm text-ink/70">{a.persona.name} ({a.persona.role}, {a.persona.company})</div>

      <div className="mt-8 rounded-md border border-amber-300 bg-amber-50 p-6 text-sm">
        <div className="font-semibold text-amber-900">Voice interview comes online in week 2.</div>
        <p className="mt-2 text-amber-900/80">
          The Realtime API integration, browser audio capture, encrypted upload, and Whisper transcription
          are scheduled for week 2 of the build. This page will host the live call and the brief side-panel.
        </p>
      </div>
    </div>
  );
}
