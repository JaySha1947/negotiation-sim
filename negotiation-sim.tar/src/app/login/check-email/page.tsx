export default function CheckEmail() {
  return (
    <main className="mx-auto max-w-md px-6 py-24">
      <h1 className="text-2xl font-semibold text-navy">Check your inbox</h1>
      <p className="mt-3 text-sm text-ink/70">
        We sent you a sign-in link. It&apos;s good for the next 15 minutes. You can close this tab.
      </p>
    </main>
  );
}
