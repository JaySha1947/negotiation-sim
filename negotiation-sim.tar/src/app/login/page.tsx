import { signIn } from '@/lib/auth';

export default function LoginPage() {
  async function handleSignIn(formData: FormData) {
    'use server';
    const email = String(formData.get('email') ?? '').trim().toLowerCase();
    if (!email) return;
    await signIn('nodemailer', { email, redirectTo: '/' });
  }

  return (
    <main className="mx-auto max-w-md px-6 py-24">
      <h1 className="text-3xl font-semibold text-navy">Negotiation Simulator</h1>
      <p className="mt-2 text-sm text-ink/70">
        Enter the email address you were invited with. We&apos;ll send a one-time sign-in link.
      </p>
      <form action={handleSignIn} className="mt-8 space-y-4">
        <input
          type="email"
          name="email"
          required
          placeholder="you@zs.com"
          className="w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm focus:border-teal focus:outline-none"
        />
        <button
          type="submit"
          className="w-full rounded-md bg-navy px-3 py-2 text-sm font-medium text-white hover:bg-navy/90"
        >
          Send sign-in link
        </button>
      </form>
    </main>
  );
}
