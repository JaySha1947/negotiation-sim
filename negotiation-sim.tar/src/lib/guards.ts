import { auth } from './auth';
import { redirect } from 'next/navigation';

export async function requireUser() {
  const session = await auth();
  if (!session?.user) redirect('/login');
  return session.user as { id: string; email: string; name?: string; role: string };
}

export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== 'ADMIN') redirect('/principal');
  return user;
}
