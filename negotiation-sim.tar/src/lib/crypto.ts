import crypto from 'node:crypto';
import { promises as fs } from 'node:fs';

// AES-256-GCM. Key from env, never logged, never persisted to DB.
// Format on disk: [12-byte IV][16-byte AUTH_TAG][ciphertext]

const KEY = (() => {
  const raw = process.env.FILE_ENCRYPTION_KEY;
  if (!raw) throw new Error('FILE_ENCRYPTION_KEY not set');
  // Accept either 32-byte hex (64 chars) or base64
  if (/^[0-9a-fA-F]{64}$/.test(raw)) return Buffer.from(raw, 'hex');
  const buf = Buffer.from(raw, 'base64');
  if (buf.length !== 32) throw new Error('FILE_ENCRYPTION_KEY must decode to 32 bytes');
  return buf;
})();

export async function encryptToFile(plaintext: Buffer, outPath: string): Promise<void> {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const ct = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  await fs.writeFile(outPath, Buffer.concat([iv, tag, ct]));
}

export async function decryptFromFile(inPath: string): Promise<Buffer> {
  const blob = await fs.readFile(inPath);
  const iv = blob.subarray(0, 12);
  const tag = blob.subarray(12, 28);
  const ct = blob.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', KEY, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(ct), decipher.final()]);
}

// Helper for generating a fresh key during setup. Run once locally:
//   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
