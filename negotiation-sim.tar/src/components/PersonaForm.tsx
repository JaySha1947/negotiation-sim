'use client';

import { useState } from 'react';

type PersonaInput = {
  id?: string;
  name: string; role: string; company: string; voice: string;
  background: string; relationshipHistory: string; competitorAwareness: string;
  primaryMotivation: string; pricingSensitivity: number; difficulty: number;
  decisionAuthority: string; communicationStyle: string;
  openingPosture: string; knownObjections: string; winConditions: string; hardLines: string;
  tactics: string;
};

const VOICES = ['alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse'];
const MOTIVATIONS = [
  'Cost minimization', 'Risk reduction', 'Career protection', 'Strategic transformation',
  'Speed to value', 'Best-in-class quality', 'Internal political wins',
];
const STYLES = ['Data-driven', 'Relational', 'Aggressive', 'Detached', 'Collaborative', 'Skeptical'];

export default function PersonaForm({
  initial,
  action,
  submitLabel = 'Save persona',
}: {
  initial?: Partial<PersonaInput>;
  action: (data: PersonaInput) => Promise<void>;
  submitLabel?: string;
}) {
  const [p, setP] = useState<PersonaInput>({
    name: initial?.name ?? '',
    role: initial?.role ?? '',
    company: initial?.company ?? '',
    voice: initial?.voice ?? 'echo',
    background: initial?.background ?? '',
    relationshipHistory: initial?.relationshipHistory ?? '',
    competitorAwareness: initial?.competitorAwareness ?? '',
    primaryMotivation: initial?.primaryMotivation ?? MOTIVATIONS[0],
    pricingSensitivity: initial?.pricingSensitivity ?? 3,
    difficulty: initial?.difficulty ?? 3,
    decisionAuthority: initial?.decisionAuthority ?? '',
    communicationStyle: initial?.communicationStyle ?? STYLES[0],
    openingPosture: initial?.openingPosture ?? '',
    knownObjections: initial?.knownObjections ?? '',
    winConditions: initial?.winConditions ?? '',
    hardLines: initial?.hardLines ?? '',
    tactics: initial?.tactics ?? '',
  });
  const [busy, setBusy] = useState(false);

  function update<K extends keyof PersonaInput>(k: K, v: PersonaInput[K]) {
    setP((prev) => ({ ...prev, [k]: v }));
  }

  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        try { await action(p); } finally { setBusy(false); }
      }}
      className="space-y-8"
    >
      <Section title="Identity">
        <Grid>
          <Text label="Persona name" value={p.name} onChange={(v) => update('name', v)} required />
          <Text label="Role / title" value={p.role} onChange={(v) => update('role', v)} required />
          <Text label="Company / client" value={p.company} onChange={(v) => update('company', v)} required />
          <Select label="Voice preset" value={p.voice} onChange={(v) => update('voice', v)} options={VOICES} />
        </Grid>
      </Section>

      <Section title="Background">
        <Textarea label="Professional background (~200 words)" rows={6}
                  value={p.background} onChange={(v) => update('background', v)} />
        <Textarea label="Relationship history with ZS" rows={3}
                  value={p.relationshipHistory} onChange={(v) => update('relationshipHistory', v)} />
        <Textarea label="Awareness of competitors and rates" rows={3}
                  value={p.competitorAwareness} onChange={(v) => update('competitorAwareness', v)} />
      </Section>

      <Section title="Negotiation profile">
        <Grid>
          <Select label="Primary motivation" value={p.primaryMotivation}
                  onChange={(v) => update('primaryMotivation', v)} options={MOTIVATIONS} />
          <Range label="Pricing sensitivity (1–5)" value={p.pricingSensitivity}
                 onChange={(v) => update('pricingSensitivity', v)} />
          <Range label="Difficulty (1–5)" value={p.difficulty}
                 onChange={(v) => update('difficulty', v)} />
          <Text label="Decision authority" value={p.decisionAuthority}
                onChange={(v) => update('decisionAuthority', v)}
                placeholder="e.g. Final sign-off up to $5M, escalates above" />
          <Select label="Communication style" value={p.communicationStyle}
                  onChange={(v) => update('communicationStyle', v)} options={STYLES} />
        </Grid>
      </Section>

      <Section title="Behavioral">
        <Textarea label="Opening posture" rows={2}
                  value={p.openingPosture} onChange={(v) => update('openingPosture', v)}
                  placeholder="How they open the conversation" />
        <Textarea label="Known objections (one per line)" rows={4}
                  value={p.knownObjections} onChange={(v) => update('knownObjections', v)}
                  placeholder="Why is this so much more than McKinsey?\nWho actually does the work?" />
        <Textarea label="Win conditions" rows={3}
                  value={p.winConditions} onChange={(v) => update('winConditions', v)} />
        <Textarea label="Hard non-negotiables" rows={3}
                  value={p.hardLines} onChange={(v) => update('hardLines', v)} />
      </Section>

      <Section title="Tactics">
        <Textarea label="Persona-specific tactics (free text)" rows={5}
                  value={p.tactics} onChange={(v) => update('tactics', v)}
                  placeholder="Opening moves, pressure points, behavioral quirks..." />
      </Section>

      <button type="submit" disabled={busy}
              className="rounded-md bg-navy px-5 py-2 text-sm font-medium text-white disabled:opacity-50">
        {busy ? 'Saving…' : submitLabel}
      </button>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-sm font-semibold uppercase tracking-wide text-ink/60">{title}</h2>
      <div className="mt-3 space-y-3">{children}</div>
    </div>
  );
}
function Grid({ children }: { children: React.ReactNode }) {
  return <div className="grid gap-3 md:grid-cols-2">{children}</div>;
}
function Text({ label, value, onChange, required, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; required?: boolean; placeholder?: string;
}) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} required={required} placeholder={placeholder}
             className="mt-1 w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm" />
    </label>
  );
}
function Textarea({ label, value, onChange, rows = 3, placeholder }: {
  label: string; value: string; onChange: (v: string) => void; rows?: number; placeholder?: string;
}) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <textarea rows={rows} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
                className="mt-1 w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm" />
    </label>
  );
}
function Select({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
              className="mt-1 w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm">
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
function Range({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label} <span className="text-ink/40">— {value}</span></span>
      <input type="range" min={1} max={5} step={1} value={value}
             onChange={(e) => onChange(Number(e.target.value))} className="mt-2 w-full" />
    </label>
  );
}
