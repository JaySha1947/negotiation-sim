'use client';

import { useState } from 'react';

type CaseInput = {
  name: string; headline: string;
  clientName: string; scope: string; value: string; timeline: string;
  competingFirms: string; complications: string;
  objective: string; constraints: string;
  pricingOptions: string; // comma-separated in UI
};

const PRICING_PRESETS = ['T&M', 'Fixed-fee', 'Outcome-based', 'Hybrid', 'Subscription'];

export default function CaseForm({
  initial, action, submitLabel = 'Save case',
}: {
  initial?: Partial<CaseInput>;
  action: (data: CaseInput) => Promise<void>;
  submitLabel?: string;
}) {
  const [c, setC] = useState<CaseInput>({
    name: initial?.name ?? '',
    headline: initial?.headline ?? '',
    clientName: initial?.clientName ?? '',
    scope: initial?.scope ?? '',
    value: initial?.value ?? '',
    timeline: initial?.timeline ?? '',
    competingFirms: initial?.competingFirms ?? '',
    complications: initial?.complications ?? '',
    objective: initial?.objective ?? '',
    constraints: initial?.constraints ?? '',
    pricingOptions: initial?.pricingOptions ?? 'T&M, Fixed-fee',
  });
  const [busy, setBusy] = useState(false);
  function update<K extends keyof CaseInput>(k: K, v: CaseInput[K]) { setC((p) => ({ ...p, [k]: v })); }

  return (
    <form onSubmit={async (e) => { e.preventDefault(); setBusy(true); try { await action(c); } finally { setBusy(false); } }}
          className="space-y-8">
      <Section title="Case identity">
        <Text label="Internal name" value={c.name} onChange={(v) => update('name', v)} required
              placeholder="e.g. Phase 2 oncology forecasting" />
        <Text label="Headline (shown on assignment cards)" value={c.headline} onChange={(v) => update('headline', v)} required
              placeholder="Pitch Phase 2 oncology forecasting, $2.4M, vs McKinsey" />
      </Section>

      <Section title="Engagement context">
        <Grid>
          <Text label="Client name" value={c.clientName} onChange={(v) => update('clientName', v)} required />
          <Text label="Value" value={c.value} onChange={(v) => update('value', v)} placeholder="$2.4M" />
          <Text label="Timeline" value={c.timeline} onChange={(v) => update('timeline', v)} placeholder="6 months" />
          <Text label="Competing firms" value={c.competingFirms} onChange={(v) => update('competingFirms', v)}
                placeholder="McKinsey, Trinity" />
        </Grid>
        <Textarea label="Scope" rows={3} value={c.scope} onChange={(v) => update('scope', v)} />
        <Textarea label="Key complications" rows={3} value={c.complications} onChange={(v) => update('complications', v)} />
      </Section>

      <Section title="Principal objective">
        <Textarea label="What does winning look like?" rows={3} value={c.objective} onChange={(v) => update('objective', v)}
                  placeholder="Land at $2M+ with 50% T&M, 50% outcome-based" />
        <Textarea label="Constraints (what the principal can&apos;t offer)" rows={3} value={c.constraints} onChange={(v) => update('constraints', v)}
                  placeholder="Margin floor 35%, no full-time onsite team" />
      </Section>

      <Section title="Pricing options in play">
        <Text label="Comma-separated" value={c.pricingOptions} onChange={(v) => update('pricingOptions', v)}
              placeholder={PRICING_PRESETS.join(', ')} />
      </Section>

      <button type="submit" disabled={busy}
              className="rounded-md bg-navy px-5 py-2 text-sm font-medium text-white disabled:opacity-50">
        {busy ? 'Saving…' : submitLabel}
      </button>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-sm font-semibold uppercase tracking-wide text-ink/60">{title}</h2>
      <div className="mt-3 space-y-3">{children}</div>
    </div>
  );
}
function Grid({ children }: { children: React.ReactNode }) {
  return <div className="grid gap-3 md:grid-cols-2">{children}</div>;
}
function Text({ label, value, onChange, required, placeholder }: any) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} required={required} placeholder={placeholder}
             className="mt-1 w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm" />
    </label>
  );
}
function Textarea({ label, value, onChange, rows = 3, placeholder }: any) {
  return (
    <label className="block text-sm">
      <span className="text-ink/60">{label}</span>
      <textarea rows={rows} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
                className="mt-1 w-full rounded-md border border-ink/20 bg-white px-3 py-2 text-sm" />
    </label>
  );
}
