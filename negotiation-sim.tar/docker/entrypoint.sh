#!/bin/sh
set -e

# Run pending migrations against the on-disk SQLite db.
echo "[entrypoint] Running prisma migrate deploy..."
npx prisma migrate deploy --schema=./prisma/schema.prisma || \
  (echo "[entrypoint] No migrations or migration failed; trying db push as fallback" && npx prisma db push --schema=./prisma/schema.prisma --accept-data-loss=false)

echo "[entrypoint] Starting Next.js..."
exec "$@"
