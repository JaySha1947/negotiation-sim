/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  experimental: {
    serverActions: {
      bodySizeLimit: '50mb', // for audio uploads
    },
  },
};

module.exports = nextConfig;
