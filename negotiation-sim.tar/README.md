# AI Negotiation Simulator

One-time tool for the ZS pricing framework project. 10 principals × 3 voice negotiations each → structured analysis → cross-cutting tactics synthesis.

See `AI_Negotiation_Simulator_Build_Brief.docx` for the locked spec.

## What's in this commit (Week 1)

- Next.js 14 + Tailwind app
- Prisma + SQLite (file at `/data/app.db`)
- Auth.js v5 magic-link email auth, role-gated (ADMIN vs PRINCIPAL)
- Admin: principals, personas, cases, assignments, sessions list
- Principal portal: assignment cards + brief view
- AES-256-GCM file encryption helpers (used in week 2 for audio)
- Persona → system-prompt assembly (used in week 2 for Realtime)
- Dockerfile + docker-compose + Caddy reverse proxy with auto-TLS

## Coming in weeks 2–4

- **Week 2**: OpenAI Realtime WebRTC integration, browser audio capture, encrypted upload, Whisper transcription
- **Week 3**: Claude Level 1/2/3 analysis, scoring rubric, principal personal report
- **Week 4**: Admin downloads (PDF/CSV), edge cases, pilot test

## Local dev

```bash
cp .env.example .env       # fill in values
npm install
npx prisma migrate dev --name init
npm run seed
npm run dev
```

App runs at http://localhost:3000.

## Deploy to VPS

See `DEPLOY.md`.

## Repo layout

```
prisma/schema.prisma       # all models
src/app/                   # Next.js routes
  login/                   # magic-link entry
  principal/               # principal portal
  admin/                   # admin panel
  interview/[id]/          # interview page (week 2 placeholder)
  api/auth/                # Auth.js handlers
src/lib/
  prisma.ts                # client singleton
  auth.ts                  # Auth.js config
  guards.ts                # requireUser / requireAdmin
  crypto.ts                # AES-256-GCM file encryption
  persona-prompt.ts        # persona+case → system prompt
src/components/
  PersonaForm.tsx
  CaseForm.tsx
docker/                    # entrypoint
Caddyfile                  # reverse proxy with auto-TLS
docker-compose.yml
Dockerfile
```
