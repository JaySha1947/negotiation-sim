// Run with: npm run seed
// Creates Jay's admin account + one sample persona and one sample case
// so you can exercise the UI right away.

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const adminEmail = (process.env.SEED_ADMIN_EMAIL ?? 'jay@example.com').toLowerCase();

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: { role: 'ADMIN' },
    create: { email: adminEmail, role: 'ADMIN', name: 'Jay' },
  });

  const persona = await prisma.persona.upsert({
    where: { id: 'seed-persona-1' },
    update: {},
    create: {
      id: 'seed-persona-1',
      name: 'Rajiv Menon',
      role: 'Head of Procurement, Global Sourcing',
      company: 'Daiichi Sankyo',
      voice: 'echo',
      background:
        'Rajiv is a 20-year procurement veteran. Previously at Pfizer where he led category sourcing for analytics and consulting spend. Holds an MBA from INSEAD. Known internally as the gatekeeper — nothing over $1M moves without his sign-off. Has lived through three big consulting RFPs and is highly skeptical of premium pricing claims.',
      relationshipHistory:
        'DSI has worked with ZS for two prior projects (forecasting and HCP targeting). Rajiv inherited the relationship. Generally satisfied but feels ZS rates have crept up.',
      competitorAwareness:
        'Knows McKinsey/QB rates and BCG GAMMA rates closely. Has data on three other firms. Will reference comparable bids unprompted.',
      primaryMotivation: 'Cost minimization',
      pricingSensitivity: 5,
      difficulty: 4,
      decisionAuthority: 'Final sign-off up to $3M; escalates above',
      communicationStyle: 'Skeptical',
      openingPosture:
        'Polite but direct. Opens with "thanks for making time — I want to be upfront, we have three other firms in the mix on this."',
      knownObjections: JSON.stringify([
        'Why is your day rate 30% above McKinsey on similar work?',
        'How much of this is senior consultants vs. analysts who could be junior?',
        'Can you commit to a fixed-fee instead of T&M?',
        'What happens if we want to extend or descope mid-flight?',
      ]),
      winConditions:
        'Wants to land at or below $1.8M, prefers fixed-fee or hybrid, wants named senior team committed in writing.',
      hardLines:
        'Will not accept pure T&M without a cap. Will not pay for travel beyond economy. Will not sign without a 30-day pilot clause.',
      tactics:
        'Uses long silences after price quotes. Re-quotes competitor numbers. Drops in "my CFO told me…" pressure. Will threaten to extend the timeline as leverage. Genuinely warms up if the consultant demonstrates technical depth.',
    },
  });

  const kase = await prisma.case.upsert({
    where: { id: 'seed-case-1' },
    update: {},
    create: {
      id: 'seed-case-1',
      name: 'DSI Phase 2 oncology forecasting',
      headline: 'Phase 2 oncology forecasting build, $2.4M, vs McKinsey',
      clientName: 'Daiichi Sankyo (DSI)',
      scope:
        'Build a Phase 2 forecasting capability covering three oncology assets across US/EU/JP. 6 months. Includes model build, training, and embedded support.',
      value: '$2.4M',
      timeline: '6 months',
      competingFirms: 'McKinsey/QB, Trinity',
      complications:
        'DSI has lost confidence in their internal forecasting after a recent miss. CFO wants outcome-tied pricing. Rajiv (procurement) wants T&M cap.',
      objective:
        'Land at $2M+ with 50% T&M-capped + 50% outcome-based on forecast accuracy at 6 months.',
      constraints:
        'Margin floor 35%. No more than 1.5 FTEs onsite in Tokyo at any time. Cannot commit to perpetual IP transfer.',
      pricingOptions: JSON.stringify(['T&M (capped)', 'Fixed-fee', 'Outcome-based', 'Hybrid']),
    },
  });

  console.log('Seeded:', { admin: adminEmail, persona: persona.name, case: kase.name });
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
