# Deploy guide

Step-by-step deployment of the AI Negotiation Simulator to a Hostinger Ubuntu VPS.

Assumes Docker + Docker Compose are already installed (you have them from Primal Notes). No PostgreSQL, no separate DB server. SQLite lives as a single file at `./data/app.db` inside the container's volume mount.

---

## Phase 0 — Pre-flight checklist

Have these ready before you start. Each one blocks deploy if missing.

| Item | Where to get it | Notes |
| --- | --- | --- |
| **Domain or subdomain** | Your registrar | e.g. `negotiation.your-domain.com`. Add an A record pointing to your VPS IP. |
| **Resend account** | resend.com | Sign up free, **verify your sending domain** (this takes ~5 min of DNS records — do it now, not later). Generate an API key. |
| **OpenAI API key** | platform.openai.com | Confirm Realtime API access on your account. |
| **Anthropic API key** | console.anthropic.com | |
| **VPS root or sudo SSH** | Hostinger panel | |

---

## Phase 1 — Push the code to GitHub (from your laptop)

This part runs on your laptop, not the VPS.

### 1.1 Extract the package

```bash
mkdir -p ~/projects/negotiation-sim
cd ~/projects/negotiation-sim
tar -xzf ~/Downloads/negotiation-sim.tar.gz
```

The repo is already initialized with one commit (`init: week 1 foundation`). Verify:

```bash
git log --oneline
# should show one commit
```

### 1.2 Create the GitHub repo

Go to **github.com/new** in your browser:
- Owner: `JaySha1947`
- Name: `negotiation-sim`
- Visibility: **Private**
- **Do NOT** initialize with a README, .gitignore, or license (the repo already has them)

### 1.3 Push

GitHub will show you the commands. Use the SSH ones (assumes you've got SSH keys set up — you do, given Primal Notes):

```bash
git remote add origin git@github.com:JaySha1947/negotiation-sim.git
git push -u origin main
```

If you prefer HTTPS + a personal access token, swap the URL.

---

## Phase 2 — Set up the VPS

### 2.1 SSH in and clone

```bash
ssh root@YOUR_VPS_IP
mkdir -p /opt/negotiation-sim
cd /opt/negotiation-sim
git clone git@github.com:JaySha1947/negotiation-sim.git .
```

If the VPS doesn't have your GitHub SSH key, either add one (`ssh-keygen` on the VPS, paste the pubkey into GitHub → Settings → SSH keys) or clone via HTTPS with a token. Same flow you used for Primal Notes.

### 2.2 Generate the two secrets

```bash
# AUTH_SECRET — used to sign session cookies
openssl rand -base64 48

# FILE_ENCRYPTION_KEY — must be 32 bytes (64 hex chars)
openssl rand -hex 32
```

Copy both values somewhere local (a temporary note, not committed).

### 2.3 Configure `.env`

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

Fill in every value. The ones that matter most:

| Variable | What |
| --- | --- |
| `APP_DOMAIN` | `negotiation.your-domain.com` (no scheme) |
| `NEXTAUTH_URL` / `AUTH_URL` | `https://negotiation.your-domain.com` (with scheme) |
| `AUTH_SECRET` | the `openssl rand -base64 48` value |
| `FILE_ENCRYPTION_KEY` | the `openssl rand -hex 32` value |
| `ADMIN_EMAILS` | your email — auto-promotes you to ADMIN on first login |
| `SMTP_HOST` | `smtp.resend.com` |
| `SMTP_PORT` | `587` |
| `SMTP_USER` | `resend` (literally the word "resend") |
| `SMTP_PASS` | your Resend API key (`re_...`) |
| `SMTP_FROM` | `"Negotiation Sim <noreply@your-verified-domain.com>"` — must use a domain Resend verified |
| `OPENAI_API_KEY` | `sk-...` |
| `ANTHROPIC_API_KEY` | `sk-ant-...` |

### 2.4 Confirm DNS before starting Caddy

Caddy will fail TLS issuance if DNS hasn't propagated. Verify first:

```bash
dig +short negotiation.your-domain.com
# must return your VPS IP
```

If it doesn't, wait. DNS can take up to an hour after you create the A record.

### 2.5 Create the data directory

The compose file mounts `./data:/data`, but the directory has to exist on the host first:

```bash
mkdir -p data
```

---

## Phase 3 — First boot

### 3.1 Build and start

```bash
docker compose build
docker compose up -d
```

### 3.2 Watch the logs

```bash
docker compose logs -f
```

Expected sequence:
1. `[entrypoint] Running prisma migrate deploy...`
2. Since no migrations are committed yet, this falls through to `prisma db push`, which creates `app.db` and applies the schema. **This is fine for a first deploy.** First-time output looks like: `🚀 Your database is now in sync with your Prisma schema.`
3. `[entrypoint] Starting Next.js...`
4. Caddy: `certificate obtained successfully` for your domain. (This takes 10–60 seconds the first time.)

If Caddy hangs on certificate issuance, see Phase 6 troubleshooting.

Press `Ctrl-C` to stop tailing. The containers keep running.

### 3.3 Seed yourself as admin

```bash
docker compose exec -e SEED_ADMIN_EMAIL=your-email@example.com app npm run seed
```

Replace the email. Use the same one in `ADMIN_EMAILS`. This also creates one sample persona (Rajiv Menon) and one sample case so the admin UI isn't empty on first look.

### 3.4 First login

1. Browse to `https://negotiation.your-domain.com`
2. Land on `/login`
3. Enter your admin email
4. Magic link arrives via Resend within ~10 seconds
5. Click → you should land on `/admin`

If the email doesn't arrive, check the **Logs** tab in your Resend dashboard. Most often: `SMTP_FROM` uses an unverified domain, or your Resend account is still in test mode and won't send to addresses other than your own.

---

## Phase 4 — Set up the engagement

In `/admin`:

1. **Personas** → create your 3–5 personas. Block 30 min per persona to write a real, detailed background. Quality of personas determines quality of the entire exercise.
2. **Cases** → create your 3–5 cases. Same effort — these should feel authentic to senior principals.
3. **Principals** → add the 10 ZS principal emails. Anyone not in this list is blocked at sign-in.
4. **Assignments** → assign 3 (persona × case) pairs to each principal. The brief calls for picking ~5 specific persona-case combos and reusing them across principals so cross-principal comparison is statistically meaningful.

Email invitations to principals don't go out automatically yet — that's the magic link flow. Either email them yourself with the URL, or we'll wire that in week 4.

---

## Phase 5 — Backups

The whole backup is two paths on disk:

```
/opt/negotiation-sim/data/app.db
/opt/negotiation-sim/data/audio/
```

Add `/opt/negotiation-sim/data` as a Syncthing share to the second VPS you already have set up. That's it.

For belt-and-suspenders, a nightly local snapshot:

```bash
cat > /etc/cron.daily/negotiation-sim-backup <<'EOF'
#!/bin/sh
TS=$(date +%Y%m%d-%H%M%S)
DEST=/opt/negotiation-sim/data/backups
mkdir -p "$DEST"
cp /opt/negotiation-sim/data/app.db "$DEST/app-${TS}.db"
find "$DEST" -name 'app-*.db' -mtime +30 -delete
EOF
chmod +x /etc/cron.daily/negotiation-sim-backup
```

---

## Phase 6 — Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Caddy log: `obtain: server responded with: ... no such host` | DNS hasn't propagated or A record wrong | `dig +short your-domain` and wait, or fix the DNS |
| Caddy log: `connection refused` on port 80 | Port 80/443 blocked | Check Hostinger firewall panel; the VPS-level firewall (`ufw`) shouldn't block these but verify with `ufw status` |
| 502 Bad Gateway from Caddy | App container crashed | `docker compose logs app` — usually a missing env var or a Prisma error |
| `Error: ENOENT: no such file or directory, open '/data/app.db'` | `./data` host dir doesn't exist or isn't writable | `mkdir -p data && chmod 755 data` then `docker compose restart app` |
| Magic link email never arrives | Resend domain not verified, or test-mode account | Check Resend dashboard → Logs. If "Domain not verified", finish DNS verification. If test mode, you can only send to your own verified email until you upgrade. |
| Logged in but landed on `/principal` instead of `/admin` | Your email wasn't in `ADMIN_EMAILS` when the user was created | `docker compose exec app npx prisma studio` → User table → flip your role to `ADMIN` |
| `Cannot find module '@prisma/client'` at runtime | Standalone build didn't copy the generated client | Rebuild: `docker compose build --no-cache app && docker compose up -d` |

---

## Phase 7 — Updates and migrations

For code-only changes:

```bash
cd /opt/negotiation-sim
git pull
docker compose build
docker compose up -d
```

For schema changes, the **right** way is to commit a migration locally before pushing. On your laptop:

```bash
# after editing prisma/schema.prisma
npx prisma migrate dev --name describe_your_change
git add prisma/migrations
git commit -m "schema: describe change"
git push
```

Then on the VPS, `git pull && docker compose up -d --build` runs `prisma migrate deploy` automatically via the entrypoint.

If you prefer to keep using `db push` in dev (faster, no migration files), that works too — just run `npx prisma db push` after pulling on the VPS, before restarting the app.

---

## Phase 8 — What this deploys (Week 1 only)

Working:
- Auth (magic link, role-gated)
- Admin: principals, personas, cases, assignments, sessions list
- Principal portal: assignments + brief view
- File encryption helpers (used in week 2)
- Persona → system prompt assembler (used in week 2)

Stubbed:
- `/interview/[id]` shows a placeholder. The Realtime WebRTC voice flow, browser audio capture, encrypted upload, Whisper transcription, and Claude analysis pipeline are weeks 2–3 work.

When those land, deploys stay simple: `git pull && docker compose up -d --build`. No new infra.
